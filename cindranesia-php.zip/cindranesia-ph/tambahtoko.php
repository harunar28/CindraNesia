<?php

include "koneksi.php";

// Create connection

 if($_SERVER['REQUEST_METHOD'] == 'POST')
 {
	 $DefaultId = 0;

   $id = $_POST['id_user'];
   $nama = $_POST['nama_toko'];
   $alamat = $_POST['alamat_toko'];
   $kota = $_POST['kota_toko'];
   $nosurat = $_POST['no_surat'];
   $arah = $_POST['arah'];
   $path = $_POST['path'];

 $GetOldIdSQL ="SELECT id_toko FROM toko ORDER BY id_toko ASC";

 $Query = mysqli_query($connect,$GetOldIdSQL);

 while($row = mysqli_fetch_array($Query)){

 $DefaultId = $row['id_toko'];
 }

 $ImagePath = "images/surat/$DefaultId.png";

 $ServerURL = "https://cindranesia.000webhostapp.com/$ImagePath";

 $InsertSQL = "insert into toko(id_user,nama_toko,alamat_toko,kota_toko,no_surat,arah,path_surat)
 values ('$id','$nama','$alamat','$kota','$nosurat','$arah','$ServerURL')";

 if(mysqli_query($connect, $InsertSQL)){

  file_put_contents($ImagePath,base64_decode($path));

  echo "OK" ;
 }

 mysqli_close($connect);
 }else{
  echo "Failed";
 }

?>
