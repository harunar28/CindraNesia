<?php
  include "koneksi.php";

 if($_SERVER['REQUEST_METHOD'] == 'POST')
 {
	 $DefaultId = 0;
	 
  $id = $_POST['id_user'];
  $nama = $_POST['nama'];
  $tempat = $_POST['tempat'];
  $tgl = $_POST['tgl'];
  $jenkel = $_POST['jenkel'];
  $alamat = $_POST['alamat'];
  $email = $_POST['email'];
  $nohp = $_POST['nohp'];
  $path = $_POST['path'];
  
$GetOldIdSQL ="SELECT id_user FROM user ORDER BY id_user ASC";

 $Query = mysqli_query($connect,$GetOldIdSQL);

 while($row = mysqli_fetch_array($Query)){

 $DefaultId = $row['id_user'];
 }

$ImagePath = "images/profil/$DefaultId.png";

 $ServerURL = "https://cindranesia.000webhostapp.com/$ImagePath";

 $InsertSQL = "UPDATE user SET nama_lengkap = '$nama', tempat_lahir = '$tempat', tgl_lahir = '$tgl', jenis_kelamin = '$jenkel', alamat = '$alamat', email = '$email', no_telp = '$nohp', path_profil = '$ServerURL' WHERE id_user='$id'";

  if(mysqli_query($connect, $InsertSQL)){

  file_put_contents($ImagePath,base64_decode($path));

  echo "OK" ;
 }

 mysqli_close($connect);
 }else{
  echo "Failed";
 }

 ?>