<?php
  include "koneksi.php";

  $id = $_GET['id_user'];

  $query = "SELECT * FROM toko where id_user = '$id' ";

  $hasil = mysqli_query($connect,$query) or die (mysql_error());

  if(mysqli_num_rows($hasil)> 0){

    $response['result']= "true" ;
    $response["data"] = array();

    // fungsi perulangan
 while ($row = mysqli_fetch_assoc($hasil)) {

     $pl = array();

     $pl["id_toko"] = $row["id_toko"];

     array_push($response["data"], $pl);


 }


 echo json_encode($response);


} else {
 $response['result']= "false" ;
}

 ?>
