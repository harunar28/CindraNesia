<?php
  include "koneksi.php";

  $id = $_POST['id'];

  $query = "DELETE FROM produk WHERE id_produk='$id' ";
  $hasil = mysqli_query($connect,$query);

  if($hasil){
    echo "OK" ;
  }else{
    echo "Failed";
  }

 ?>
