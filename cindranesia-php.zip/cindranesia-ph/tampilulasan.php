<?php
  include "koneksi.php";

  $id = $_GET['id_produk'];

  $query = "SELECT ulasan.id_ulasan AS id_ulasan, ulasan.ulasan AS ulasan, ulasan.id_user AS iduser,
	user.nama_lengkap AS nama FROM user LEFT JOIN ulasan ON ulasan.id_user = user.id_user where ulasan.id_produk = '$id' ";

  $hasil = mysqli_query($connect,$query) or die (mysql_error());

  if(mysqli_num_rows($hasil)> 0){

    $response['result']= "true" ;
    $response["data"] = array();

    // fungsi perulangan
 while ($row = mysqli_fetch_assoc($hasil)) {

     $pl = array();

     $pl["id_ulasan"] = $row["id_ulasan"];
     $pl["nama"] = $row["nama"];
     $pl["ulasan"] = $row["ulasan"];

     array_push($response["data"], $pl);


 }


 echo json_encode($response);


} else {
 $response['result']= "false" ;
}

 ?>
