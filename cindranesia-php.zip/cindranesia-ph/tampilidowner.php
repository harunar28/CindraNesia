<?php
  include "koneksi.php";

  $email = $_GET['email'];
  
  $query = "SELECT * FROM user WHERE email='$email'";

  $hasil = mysqli_query($connect,$query) or die (mysqli_error());

  if(mysqli_num_rows($hasil)> 0){

    $response['result']= "true" ;
    $response["data"] = array();

    // fungsi perulangan
 while ($row = mysqli_fetch_assoc($hasil)) {

     $pl = array();

     $pl["id_user"] = $row["id_user"];

     array_push($response["data"], $pl);
 }


 echo json_encode($response);


} else {
 $response['result']= "false" ;
}

 ?>