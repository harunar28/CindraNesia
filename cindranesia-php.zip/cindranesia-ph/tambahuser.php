<?php
  include "koneksi.php";

  $nama_lengkap = $_POST['nama_lengkap'];
  $username = $_POST['username'];
  $email = $_POST['email'];
  $role = 'user';
  $no_telp = $_POST['no_telp'];
  $pass = $_POST['password'];

  $password = md5($pass);
  $query = "INSERT INTO user(nama_lengkap,username,email,role,no_telp,password) VALUES('$nama_lengkap','$username','$email','$role','$no_telp','$password')";
  $hasil = mysqli_query($connect,$query);

  if($hasil){
    echo "OK" ;
  }else{
    echo "Failed";
  }

 ?>
