<?php
  include "koneksi.php";

  $id = $_GET['id_produk'];

  $query = "SELECT * FROM produk where id_produk = '$id' ";


  $hasil = mysqli_query($connect,$query) or die (mysql_error());

  if(mysqli_num_rows($hasil)> 0){

    $response['result']= "true" ;
    $response["data"] = array();

    // fungsi perulangan
 while ($row = mysqli_fetch_assoc($hasil)) {

     $pl = array();

     $pl["jenis_produk"] = $row["jenis_produk"];
     $pl["judul_produk"] = $row["judul_produk"];
     $pl["deskripsi_produk"] = $row["deskripsi_produk"];
     $pl["harga_produk"] = $row["harga_produk"];
     $pl["path_produk"] = $row["path_produk"];

     array_push($response["data"], $pl);


 }


 echo json_encode($response);


} else {
 $response['result']= "false" ;
}

 ?>
