<?php

include "koneksi.php";

// Create connection

 if($_SERVER['REQUEST_METHOD'] == 'POST')
 {
	 $DefaultId = 0;

   $id = $_POST['id_toko'];
   $jenis = $_POST['jenis_produk'];
   $judul = $_POST['judul_produk'];
   $desk = $_POST['deskripsi_produk'];
   $harga = $_POST['harga_produk'];
   $path = $_POST['path'];

 $GetOldIdSQL ="SELECT id_produk FROM produk ORDER BY id_produk ASC";

 $Query = mysqli_query($connect,$GetOldIdSQL);

 while($row = mysqli_fetch_array($Query)){

 $DefaultId = $row['id_produk'];
 }

 $ImagePath = "images/produk/$DefaultId.png";

 $ServerURL = "https://cindranesia.000webhostapp.com/$ImagePath";

 $InsertSQL = "insert into produk(id_toko,jenis_produk,judul_produk,deskripsi_produk,harga_produk,path_produk)
 values ('$id','$jenis','$judul','$desk','$harga','$ServerURL')";

 if(mysqli_query($connect, $InsertSQL)){

  file_put_contents($ImagePath,base64_decode($path));

  echo "OK" ;
 }

 mysqli_close($connect);
 }else{
  echo "Failed";
 }

?>
