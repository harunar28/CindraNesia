<?php
  include "koneksi.php";

  $id = $_GET['id_toko'];

  $query = "SELECT user.nama_lengkap AS nama_lengkap, produk.judul_produk AS judul_produk, 
		pemesanan.jumlah_pesan  AS jml_pesan, pemesanan.tgl_pesan AS tgl_pesan
		FROM pemesanan
		INNER JOIN user ON user.id_user = pemesanan.id_user
		INNER JOIN produk ON produk.id_produk = pemesanan.id_produk
		WHERE pemesanan.id_toko = '$id'";

  $hasil = mysqli_query($connect,$query) or die (mysql_error());

  if(mysqli_num_rows($hasil)> 0){

    $response['result']= "true" ;
    $response["data"] = array();

    // fungsi perulangan
 while ($row = mysqli_fetch_assoc($hasil)) {

     $pl = array();

     $pl["nama"] = $row["nama_lengkap"];
     $pl["judul"] = $row["judul_produk"];
     $pl["jumlah"] = $row["jml_pesan"];
     $pl["tanggal"] = $row["tgl_pesan"];

     array_push($response["data"], $pl);


 }


 echo json_encode($response);


} else {
 $response['result']= "false" ;
}

 ?>