<?php
  include "koneksi.php";

  $id = $_GET['id_user'];
  
  $query = "SELECT * FROM user WHERE id_user='$id'";

  $hasil = mysqli_query($connect,$query) or die (mysqli_error());

  if(mysqli_num_rows($hasil)> 0){

    $response['result']= "true" ;
    $response["data"] = array();

    // fungsi perulangan
 while ($row = mysqli_fetch_assoc($hasil)) {

     $pl = array();

     $pl["path_profil"] = $row["path_profil"];
     $pl["nama_lengkap"] = $row["nama_lengkap"];
     $pl["tempat_lahir"] = $row["tempat_lahir"];
     $pl["tgl_lahir"] = $row["tgl_lahir"];
     $pl["jenis_kelamin"] = $row["jenis_kelamin"];
     $pl["alamat"] = $row["alamat"];
     $pl["email"] = $row["email"];
     $pl["no_telp"] = $row["no_telp"];

     array_push($response["data"], $pl);


 }


 echo json_encode($response);


} else {
 $response['result']= "false" ;
}

 ?>