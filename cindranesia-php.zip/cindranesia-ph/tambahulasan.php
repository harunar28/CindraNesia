<?php
  include "koneksi.php";

  $id_produk = $_POST['id_produk'];
  $id_user = $_POST['id_user'];
  $ulasan = $_POST['ulasan'];

  $query = "INSERT INTO ulasan(id_produk,id_user,ulasan,tgl_ulasan) VALUES('$id_produk','$id_user','$ulasan', now())";
  $hasil = mysqli_query($connect,$query);

  if($hasil){
    echo "OK" ;
  }else{
    echo "Failed";
  }

 ?>
