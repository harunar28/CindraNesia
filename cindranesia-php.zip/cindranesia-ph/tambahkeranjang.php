<?php
  include "koneksi.php";

  $iduser = $_POST['id_user'];
  $idtoko = $_POST['id_toko'];
  $idproduk = $_POST['id_produk'];
  $jmh = $_POST['jumlah'];

  $query = "INSERT INTO keranjang(id_user,id_toko,id_produk,jml_pesan) VALUES('$iduser','$idtoko','$idproduk','$jmh')";
  $hasil = mysqli_query($connect,$query);

  if($hasil){
    echo "OK" ;
  }else{
    echo "Failed";
  }

 ?>
