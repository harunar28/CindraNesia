<?php
  include "koneksi.php";

  $id = $_GET['id_produk'];

  $query = "SELECT produk.id_produk AS id_produk, produk.judul_produk AS judul_produk, 
  produk.deskripsi_produk AS deskripsi_produk, produk.path_produk AS path_produk,toko.id_toko AS id_toko,toko.arah AS arah ,produk.harga_produk AS harga_produk , toko.nama_toko AS nama_toko, toko.alamat_toko AS alamat_toko,
	toko.kota_toko AS kota_toko FROM produk LEFT JOIN toko ON toko.id_toko = produk.id_toko WHERE id_produk = '$id'";

  $hasil = mysqli_query($connect,$query) or die (mysql_error());

  if(mysqli_num_rows($hasil)> 0){

    $response['result']= "true" ;
    $response["data"] = array();

    // fungsi perulangan
 while ($row = mysqli_fetch_assoc($hasil)) {

     $pl = array();

     $pl["id_produk"] = $row["id_produk"];
     $pl["id_toko"] = $row["id_toko"];
     $pl["judul_produk"] = $row["judul_produk"];
     $pl["deskripsi"] = $row["deskripsi_produk"];
     $pl["nama_toko"] = $row["nama_toko"];
     $pl["alamat_toko"] = $row["alamat_toko"];
     $pl["kota_toko"] = $row["kota_toko"];
     $pl["arah"] = $row["arah"];
     $pl["harga_produk"] = $row["harga_produk"];
     $pl["path"] = $row["path_produk"];

     array_push($response["data"], $pl);


 }


 echo json_encode($response);


} else {
 $response['result']= "false" ;
}

 ?>