<?php
  $server = "localhost";
  $username = "id5366955_datbas_cindranesia";
  $password = "esti123";
  $db = "id5366955_datbas_cindranesia";

  $connect = new mysqli($server, $username, $password,$db) or die("Error : ".mysql_error());
 ?>