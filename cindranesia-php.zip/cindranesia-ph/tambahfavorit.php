<?php
  include "koneksi.php";

  $iduser = $_POST['id_user'];
  $idtoko = $_POST['id_toko'];
  $idproduk = $_POST['id_produk'];

  $query = "INSERT INTO favorit(id_user,id_toko,id_produk) VALUES('$iduser','$idtoko','$idproduk')";
  $hasil = mysqli_query($connect,$query);

  if($hasil){
    echo "OK" ;
  }else{
    echo "Failed";
  }

 ?>
